# Telegram UNO Bot (Render Docker)

## Features
- `/start` help
- `/join` joins the lobby in a group
- `/leave` leaves before the game starts
- `/close` closes joining and starts the game
- `/cancel` lets the lobby creator cancel the lobby/game
- Basic UNO cards and turn-based play through private-chat buttons

## Setup
1. Create a bot with `@BotFather` and copy its token.
2. Create a GitHub repository and upload `main.py`, `requirements.txt`, and `Dockerfile`.
3. On Render, create a **Background Worker** from the repo and select Docker runtime.
4. In Render Environment, add `BOT_TOKEN` with your BotFather token.
5. Deploy.
6. Open the bot privately and send `/start` before joining a group game.
7. Add the bot to your group. Use `/join` in the group for each player; then the lobby creator uses `/close`.

## Notes
- This is a starter implementation, not a tournament-grade UNO engine.
- Game state is kept in memory; active games are lost when the service restarts.
- Each player must open the bot and send `/start` so the bot can DM their hand.
- Never share your bot token publicly.
