import os
import random
import logging
from dataclasses import dataclass, field
from typing import Optional

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
)
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, ContextTypes,
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("uno-bot")

BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is missing.")

COLORS = ["Red", "Yellow", "Green", "Blue"]
COLOR_EMOJI = {"Red": "🔴", "Yellow": "🟡", "Green": "🟢", "Blue": "🔵"}
VALUES = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "Skip", "Reverse", "+2"]
WILD_VALUES = ["Wild", "Wild+4"]

@dataclass
class Player:
    user_id: int
    name: str
    hand: list[str] = field(default_factory=list)

@dataclass
class Game:
    chat_id: int
    host_id: int
    players: dict[int, Player] = field(default_factory=dict)
    lobby_open: bool = True
    deck: list[str] = field(default_factory=list)
    discard: list[str] = field(default_factory=list)
    current_color: Optional[str] = None
    turn_index: int = 0
    direction: int = 1
    started: bool = False
    lock_color_picker_for: Optional[int] = None

games: dict[int, Game] = {}

def make_deck() -> list[str]:
    cards = []
    for color in COLORS:
        cards.append(f"{color}:0")
        for value in VALUES[1:]:
            copies = 1 if value in ("Skip", "Reverse", "+2") else 2
            cards.extend([f"{color}:{value}"] * copies)
    for _ in range(4):
        cards.append("Wild:Wild")
        cards.append("Wild:Wild+4")
    random.shuffle(cards)
    return cards

def card_parts(card: str):
    color, value = card.split(":", 1)
    return color, value

def fmt_card(card: str) -> str:
    color, value = card_parts(card)
    if color == "Wild":
        return "🌈 " + ("Wild +4" if value == "Wild+4" else "Wild")
    return f"{COLOR_EMOJI[color]} {value}"

def current_player(game: Game) -> Player:
    return list(game.players.values())[game.turn_index]

def next_turn(game: Game, steps: int = 1):
    count = len(game.players)
    game.turn_index = (game.turn_index + game.direction * steps) % count

def top_card(game: Game) -> str:
    return game.discard[-1]

def can_play(game: Game, card: str) -> bool:
    color, value = card_parts(card)
    top_color, top_value = card_parts(top_card(game))
    return color == "Wild" or color == game.current_color or value == top_value

def draw_cards(game: Game, player: Player, count: int = 1):
    for _ in range(count):
        if not game.deck:
            if len(game.discard) > 1:
                top = game.discard.pop()
                game.deck = game.discard[:]
                game.discard = [top]
                random.shuffle(game.deck)
            else:
                return
        if game.deck:
            player.hand.append(game.deck.pop())

def game_status(game: Game) -> str:
    p = current_player(game)
    return (
        f"🃏 *UNO game is on!*\n\n"
        f"Top card: {fmt_card(top_card(game))}\n"
        f"Current color: {COLOR_EMOJI[game.current_color]} {game.current_color}\n"
        f"Turn: *{p.name}*\n"
        f"Players: {len(game.players)}"
    )

def game_keyboard(game: Game, player_id: int):
    p = game.players[player_id]
    rows = []
    playable = [i for i, c in enumerate(p.hand) if can_play(game, c)]
    for i in playable:
        rows.append([InlineKeyboardButton(fmt_card(p.hand[i]), callback_data=f"play:{game.chat_id}:{player_id}:{i}")])
    rows.append([InlineKeyboardButton("➕ Draw card", callback_data=f"draw:{game.chat_id}:{player_id}")])
    return InlineKeyboardMarkup(rows)

async def send_turn(game: Game, context: ContextTypes.DEFAULT_TYPE):
    p = current_player(game)
    status = game_status(game)
    try:
        await context.bot.send_message(
            chat_id=game.chat_id,
            text=status,
            parse_mode="Markdown",
        )
        await context.bot.send_message(
            chat_id=p.user_id,
            text=f"Your hand ({len(p.hand)} cards). Tap a playable card or draw:",
            reply_markup=game_keyboard(game, p.user_id),
        )
    except Exception as e:
        await context.bot.send_message(
            chat_id=game.chat_id,
            text=f"⚠️ I couldn't DM {p.name}. They must open the bot and press /start first.",
        )
        log.info("Could not DM current player: %s", e)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "🃏 *UNO Bot*\n\n"
        "Add me to a group and use:\n"
        "/join — join the lobby\n"
        "/leave — leave before the game starts\n"
        "/close — close joining and start the game\n\n"
        "During a game, the current player gets their cards in a private chat. "
        "Open this bot and press /start before playing.",
        parse_mode="Markdown",
    )

async def join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not user:
        return
    if chat.type == "private":
        await update.effective_message.reply_text("Use /join in the group where you want to play.")
        return
    game = games.get(chat.id)
    if game and game.started:
        await update.effective_message.reply_text("A game is already running here.")
        return
    if not game:
        game = Game(chat_id=chat.id, host_id=user.id)
        games[chat.id] = game
    if not game.lobby_open:
        await update.effective_message.reply_text("Joining is closed. Start a new game after this one ends.")
        return
    if user.id in game.players:
        await update.effective_message.reply_text(f"{user.first_name}, you're already in!")
        return
    game.players[user.id] = Player(user_id=user.id, name=user.first_name)
    await update.effective_message.reply_text(
        f"✅ {user.first_name} joined UNO!\nPlayers ({len(game.players)}): " +
        ", ".join(p.name for p in game.players.values()) +
        "\nUse /close when everyone has joined."
    )

async def leave(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not user:
        return
    game = games.get(chat.id)
    if not game or game.started:
        await update.effective_message.reply_text("There isn't an open lobby to leave.")
        return
    if user.id in game.players:
        del game.players[user.id]
        await update.effective_message.reply_text(f"👋 {user.first_name} left the UNO lobby.")
        if not game.players:
            games.pop(chat.id, None)
    else:
        await update.effective_message.reply_text("You're not in the lobby.")

async def close_lobby(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not user:
        return
    game = games.get(chat.id)
    if not game or not game.players:
        await update.effective_message.reply_text("Nobody has joined yet. Use /join first.")
        return
    if user.id != game.host_id and not user.id in game.players:
        await update.effective_message.reply_text("Only the person who opened the lobby can start this game.")
        return
    if len(game.players) < 2:
        await update.effective_message.reply_text("At least 2 players are needed. Ask a friend to /join.")
        return
    game.lobby_open = False
    game.started = True
    game.deck = make_deck()
    for p in game.players.values():
        p.hand = [game.deck.pop() for _ in range(7)]
    first = game.deck.pop()
    while card_parts(first)[0] == "Wild":
        game.deck.insert(0, first)
        random.shuffle(game.deck)
        first = game.deck.pop()
    game.discard = [first]
    game.current_color = card_parts(first)[0]
    game.turn_index = 0
    await update.effective_message.reply_text("🚦 Joining closed! UNO starts now. Everyone must have opened the bot and sent /start.")
    await send_turn(game, context)

async def cancel_game(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    user = update.effective_user
    if not chat or not user:
        return
    game = games.get(chat.id)
    if not game:
        await update.effective_message.reply_text("No active UNO lobby or game.")
        return
    if user.id != game.host_id:
        await update.effective_message.reply_text("Only the player who opened the lobby can close/cancel this game.")
        return
    games.pop(chat.id, None)
    await update.effective_message.reply_text("🛑 UNO lobby/game closed.")

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = query.from_user
    data = query.data or ""
    parts = data.split(":")
    if len(parts) < 3:
        return
    action, chat_id_s, player_id_s = parts[:3]
    try:
        chat_id, player_id = int(chat_id_s), int(player_id_s)
    except ValueError:
        return
    game = games.get(chat_id)
    if not game or not game.started:
        await query.edit_message_text("This game is no longer active.")
        return
    if user.id != player_id or player_id not in game.players:
        await query.answer("This isn't your hand!", show_alert=True)
        return
    if current_player(game).user_id != player_id:
        await query.answer("Wait for your turn.", show_alert=True)
        return
    player = game.players[player_id]

    if action == "draw":
        draw_cards(game, player, 1)
        await query.edit_message_text(f"You drew a card. Your hand now has {len(player.hand)} cards. Your turn ends.")
        next_turn(game)
        await send_turn(game, context)
        return

    if action == "color":
        if len(parts) < 4:
            return
        chosen = parts[3]
        if chosen not in COLORS:
            return
        game.current_color = chosen
        game.lock_color_picker_for = None
        await query.edit_message_text(f"Color chosen: {COLOR_EMOJI[chosen]} {chosen}")
        await send_turn(game, context)
        return

    if action == "play":
        if len(parts) < 4:
            return
        try:
            index = int(parts[3])
        except ValueError:
            return
        if index < 0 or index >= len(player.hand):
            await query.edit_message_text("That card is no longer in your hand. Try /start and check the current game.")
            return
        card = player.hand[index]
        if not can_play(game, card):
            await query.answer("You can't play that card.", show_alert=True)
            return
        color, value = card_parts(card)
        player.hand.pop(index)
        game.discard.append(card)
        if color != "Wild":
            game.current_color = color
        await query.edit_message_text(f"Played {fmt_card(card)}.")

        if not player.hand:
            await context.bot.send_message(chat_id=chat_id, text=f"🏆 {player.name} wins UNO!")
            games.pop(chat_id, None)
            return

        if value == "Reverse":
            game.direction *= -1
            if len(game.players) == 2:
                next_turn(game, 2)
            else:
                next_turn(game)
        elif value == "Skip":
            next_turn(game, 2)
        elif value == "+2":
            next_turn(game)
            draw_cards(game, current_player(game), 2)
            next_turn(game)
        elif value == "Wild+4":
            target_player = current_player(game)
            draw_cards(game, target_player, 4)
            target_id = target_player.user_id
            kb = InlineKeyboardMarkup([[
                InlineKeyboardButton(f"{COLOR_EMOJI[c]} {c}", callback_data=f"color:{chat_id}:{target_id}:{c}")
                for c in COLORS
            ]])
            await context.bot.send_message(
                chat_id=target_id,
                text="Choose the next color:",
                reply_markup=kb,
            )
            # The wild +4 player has already ended their turn; wait for next player to choose color.
            game.lock_color_picker_for = target_id
            return
        elif value == "Wild":
            target_id = current_player(game).user_id
            kb = InlineKeyboardMarkup([[
                InlineKeyboardButton(f"{COLOR_EMOJI[c]} {c}", callback_data=f"color:{chat_id}:{target_id}:{c}")
                for c in COLORS
            ]])
            await context.bot.send_message(chat_id=target_id, text="Choose the next color:", reply_markup=kb)
            game.lock_color_picker_for = target_id
            return
        else:
            next_turn(game)
        await send_turn(game, context)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("join", join))
    app.add_handler(CommandHandler("leave", leave))
    app.add_handler(CommandHandler("close", close_lobby))
    app.add_handler(CommandHandler("cancel", cancel_game))
    app.add_handler(CallbackQueryHandler(callback))
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
